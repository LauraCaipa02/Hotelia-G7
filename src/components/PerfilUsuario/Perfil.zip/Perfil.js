import axios from "axios";
import "./Perfil.css";
import { useState, useEffect } from "react";
import Imageperfil from "../../components/PerfilUsuario/Fotoperfil";
import Boton from "../Botones/Botones";
import { faPenToSquare } from "@fortawesome/free-solid-svg-icons";
import Modal from "../Modal/Modal";
import Modalc from "../Modal/Modalc";

function Info() {
    const [estadoModalDatos, cambiarEstadoDatos] = useState(false);
    const [estadoModalDatosC, cambiarEstadoDatosC] = useState(false);

    //1.Definir url del api a la que me va a conectar
    const url = "https://hoteliakuepag7.herokuapp.com/users/1234567890";

    //2. Generar función asincrona
    const getData = async () => {
        const response = axios.get(url);
        return response;
    };

    //3. UseState para guardar la respuesta de la petición

    const [list, setList] = useState([]);

    //4.Crear otro estado para refrescar el listado después de eliminar
    const [upList, setUplist] = useState([false]);


    //6. Hook useEffect ejecuta funciones cada vez que renderizamos un componente.
    useEffect(() => {
        getData().then((response) => {
            setList(response.data);
        });
    }, [upList]); //Se actualiza el listado cada vez que cambie el estado up List
    console.log(list);

    return (
        <main className="maininfo">
            <div className="container_pandi">
                <Imageperfil foto={`https://hoteliakuepag7.herokuapp.com${list.img}`} descf={"susana"} />

                <div className="container_info" key={list._id}>
                    <div className="container">
                        <div className="label">Tipo de Documento de identidad</div>
                        <div className="input">{list.tipodoc}</div>
                    </div>

                    <div className="container">
                        <div className="label">Número de Documento de identidad</div>
                        <div className="input ">{list._id}</div>
                    </div>

                    <div className="container">
                        <div className="label">Fecha De Nacimiento</div>
                        <div className="input">{list.fnacimiento}</div>
                    </div>

                    <div className="container">
                        <div className="label">Nombre Completo</div>
                        <div className="input">
                            {list.nombre} {list.apellido}
                        </div>
                    </div>

                    <div className="container">
                        <div className="label">Género</div>
                        <div className="input">{list.genero}</div>
                    </div>

                    <div className="container">
                        <div className="label">País de Origen</div>
                        <div className="input">{list.paisorigen}</div>
                    </div>

                    <div className="container">
                        <div className="label">Teléfono</div>
                        <div className="containerd">
                            <div className="input inputp">+57 </div>
                            <div className="input inputt">{list.telefono}</div>
                        </div>
                    </div>

                    <div className="container">
                        <div className="label">Correo Electrónico</div>
                        <div className="input">{list.email}</div>
                    </div>

                    <div className="container">
                        <div className="label">Contraseña</div>
                        <input
                            type="password"
                            className="input inputinput"
                            value={list.password}
                            disabled
                        />
                    </div>
                </div>
            </div>

            <div className="container_btn_pu">
                <Boton
                    click={() => cambiarEstadoDatos(!estadoModalDatos)}
                    texto={"Editar Datos Contacto"}
                    icono={faPenToSquare}
                    clase={"btn_blue btn_pb"}
                />
                <Boton
                    click={() => cambiarEstadoDatosC(!estadoModalDatosC)}
                    texto={"Cambiar Contraseña"}
                    icono={faPenToSquare}
                    clase={"btn_oranje btn_po"}
                />
            </div>

            <Modal
                estado={estadoModalDatos}
                cambiarEstado={cambiarEstadoDatos}
                title="DATOS DE CONTACTO"
                name={"correo"}
                label={"Correo Electrónico"}
                tipo="text"
                labeltwo={"Teléfono"}
                placeholder={list.email}
                placeholderthree={list.telefono}
            />

            <Modalc
                estado={estadoModalDatosC}
                cambiarEstado={cambiarEstadoDatosC}
                title="DATOS DE CONTACTO"
                name={"contraseña"}
                label={"Contraseña Actual"}
                tipo="password"
                placeholder={"******"}
                labeltwo={"Contraseña Nueva"}
                labelthree={"Confirmar Contraseña"}
                placeholdertwo={"+57"}
            />
        </main>
    );
}

export default Info;
